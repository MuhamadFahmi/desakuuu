# LineBotExample
For example of line chat bot use PHP use Line Messaging SDK From https://github.com/line/line-bot-sdk-php 

About How to create How to create Line Bot you can read http://gueprogramer.com/uncategorized/create-line-chat-bot-and-messaging-api-use-php-simple-example/
